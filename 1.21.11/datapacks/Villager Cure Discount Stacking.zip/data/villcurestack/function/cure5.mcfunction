data modify entity @s Gossips set value []
data modify entity @s Gossips prepend value {Type:"major_positive",Value:100,Target:[I;1,6,1,1]}
execute at @s run data modify entity @s Gossips[0].Target set from entity @p UUID

tag @s remove knize_cure4



tag @s add knize_cure5
tag @s add knize_curee

# made by KNIZE1007
# Officialy published only on Modrinth and planet minecraft
# Other websites have reuploaded without my consent and are in breach of the licence