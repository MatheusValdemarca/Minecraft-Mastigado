schedule function villcurestack:1s 1s
#execute as @e[type=zombie_villager] run execute store result score @s ConversionTimer run data get entity @s ConversionTime

tag @e[type=zombie_villager] remove knize_curee
execute as @e[type=villager,tag=!knize_curee] if predicate villcurestack:cures run function villcurestack:decidediscount

# made by KNIZE_1007
# Officialy published only on Modrinth and planet minecraft
# Other websites have reuploaded without my consent and are in breach of the licence
