execute at @s run data merge entity @e[type=minecraft:zombie_villager,limit=1,sort=nearest] {ConversionTime:80}
# made by KNIZE_1007
# Officialy published only on Modrinth and planet minecraft
# Other websites have reuploaded without my consent and are in breach of the licence