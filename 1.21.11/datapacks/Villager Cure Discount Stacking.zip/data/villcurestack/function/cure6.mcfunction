data modify entity @s Gossips set value []
data modify entity @s Gossips prepend value {Type:"major_positive",Value:120,Target:[I;1,7,1,1]}
execute at @s run data modify entity @s Gossips[0].Target set from entity @p UUID

tag @s remove knize_cure5



tag @s add knize_cure6
tag @s add knize_curee

# made by KNIZE 1007
# Officialy published only on Modrinth and planet minecraft
# Other websites have reuploaded without my consent and are in breach of the licence