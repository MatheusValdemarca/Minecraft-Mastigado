data modify entity @s Gossips set value []
data modify entity @s Gossips prepend value {Type:"major_positive",Value:180,Target:[I;21,2,1,1]}
execute at @s run data modify entity @s Gossips[0].Target set from entity @p UUID

tag @s remove knize_cure8



tag @s add knize_cure9
tag @s add knize_curee


# made by K N I Z E _ 1 0 0 7 
# O f f i c i a l y published only on M o d r i n t h and p l a n e t m i n e c r a f t
# Other websites have reuploaded without my consent and are in breach of the licence