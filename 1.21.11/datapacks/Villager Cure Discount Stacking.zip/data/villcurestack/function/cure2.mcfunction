#execute at @s run summon villager ~ ~ ~ {Tags:["REPLACEMENT"]}
#data modify entity @e[type=villager,limit=1,sort=nearest,tag=REPLACEMENT] VillagerData merge from entity @s VillagerData
#data modify entity @e[type=villager,limit=1,sort=nearest,tag=REPLACEMENT] Offers merge from entity @s Offers
#data modify entity @e[type=villager,limit=1,sort=nearest,tag=REPLACEMENT] Brain merge from entity @s Brain
#data modify entity @e[type=villager,limit=1,sort=nearest,tag=REPLACEMENT] Gossips prepend value {Type:"major_positive",Value:40,Target:[I;1,1,1,1]}

#potential fix for multiplayer compat - need to work it out
#execute at @s run summon villager ~ ~ ~ {NoGravity:1b,Invulnerable:1b,CanPickUpLoot:0b,Tags:["KNIZE_VILLGOSSIP"],active_effects:[{id:"minecraft:strength",amplifier:10,duration:-1,show_particles:0b}]}
#data modify entity @e[type=villager,limit=1,sort=nearest,tag=KNIZE_VILLGOSSIP] Gossips insert 0 from entity @s Gossips
#tell @s a

data modify entity @s Gossips set value []
data modify entity @s Gossips prepend value {Type:"major_positive",Value:40,Target:[I;1,1,1,1]}
#execute at @e[type=villager,limit=1,sort=nearest,tag=REPLACEMENT] run data modify entity @e[type=villager,limit=1,sort=nearest,tag=REPLACEMENT] Gossips[0].Target set from entity @p UUID
execute at @s run data modify entity @s Gossips[0].Target set from entity @p UUID

#data modify entity @s Gossips append from entity @e[type=villager,limit=1,sort=nearest,tag=KNIZE_VILLGOSSIP] Gossips
#kill @e[type=villager,limit=1,sort=nearest,tag=KNIZE_VILLGOSSIP]

#tag @e[type=villager,limit=1,sort=nearest,tag=REPLACEMENT] remove knize_cure1
tag @s remove knize_cure1

#execute if entity @s[tag=knize_chickenvillager] run tag @e[type=villager,limit=1,sort=nearest,tag=REPLACEMENT] add knize_chickenvillager
#execute if entity @s[tag=knize_chickenvillager] run tag @s add knize_chickenvillager

#tag @e[type=villager,limit=1,sort=nearest,tag=REPLACEMENT] add knize_cure2
#tag @e[type=villager,limit=1,sort=nearest,tag=REPLACEMENT] add knize_curee

tag @s add knize_cure2
tag @s add knize_curee

#execute as @e[type=villager,limit=1,sort=nearest,tag=REPLACEMENT,tag=!knize_chickenvillager] at @s run ride @s mount @e[type=minecart,sort=nearest,limit=1,distance=..1]
#execute as @e[type=villager,limit=1,sort=nearest,tag=REPLACEMENT,tag=knize_chickenvillager] at @s run ride @s mount @e[type=chicken,sort=nearest,limit=1,distance=..2]

#execute as @s[tag=!knize_chickenvillager] at @s run ride @s mount @e[type=minecart,sort=nearest,limit=1,distance=..1]
#execute as @s[tag=knize_chickenvillager] at @s run ride @s mount @e[type=chicken,sort=nearest,limit=1,distance=..2]

#tag @e[type=villager,limit=1,sort=nearest,tag=REPLACEMENT] remove REPLACEMENT
#kill @s

# made by KNIZE_1007
# Officialy published only on Modrinth and planet minecraft
# Other websites have reuploaded without my consent and are in breach of the licence