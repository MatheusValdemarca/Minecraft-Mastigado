#data merge entity @s {Gossips:[]}
#data modify entity @s Gossips prepend value {Type:"major_positive",Value:20,Target:[I;1,1,1,1]}
#data modify entity @s Gossips[0].Target set from entity @p UUID
tag @s add knize_curee
tag @s add knize_cure1
execute as @s if predicate villcurestack:riding_chicken run tag @s add knize_chickenvillager

# made by KNIZE_1007
# Officialy published only on Modrinth and planet minecraft
# Other websites have reuploaded without my consent and are in breach of the licence