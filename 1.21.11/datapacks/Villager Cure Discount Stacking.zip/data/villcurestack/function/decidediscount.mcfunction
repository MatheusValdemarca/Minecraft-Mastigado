execute if entity @s[tag=knize_cure10] run function villcurestack:cure10
execute if entity @s[tag=knize_cure9] run function villcurestack:cure10
execute if entity @s[tag=knize_cure8] run function villcurestack:cure9
execute if entity @s[tag=knize_cure7] run function villcurestack:cure8
execute if entity @s[tag=knize_cure6] run function villcurestack:cure7
execute if entity @s[tag=knize_cure5] run function villcurestack:cure6
execute if entity @s[tag=knize_cure4] run function villcurestack:cure5
execute if entity @s[tag=knize_cure3] run function villcurestack:cure4
execute if entity @s[tag=knize_cure2] run function villcurestack:cure3
execute if entity @s[tag=knize_cure1] run function villcurestack:cure2
execute if entity @s[tag=!knize_curee] run function villcurestack:test

# made by KNIZE_1007
# Officialy published only on Modrinth and planet minecraft
# Other websites have reuploaded without my consent and are in breach of the licence