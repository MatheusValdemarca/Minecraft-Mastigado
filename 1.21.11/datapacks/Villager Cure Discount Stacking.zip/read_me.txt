made by KNIZE_1007

**By downloading the datapack, you agree with the following:**
You are not allowed to redistribute this datapack in any way

You may modify this datapack, but distributing modified versions is not allowed

You can use this datapack in videos and other, but provide a link to this page in the description

You cannot take credit for the making of this datapack

You may download this datapack only from official sources - currently it is only on planet minecraft and modrinth